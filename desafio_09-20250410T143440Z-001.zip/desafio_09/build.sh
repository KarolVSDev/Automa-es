#!/bin/bash

zip -r "desafio_09.zip" * -x "desafio_09.zip"