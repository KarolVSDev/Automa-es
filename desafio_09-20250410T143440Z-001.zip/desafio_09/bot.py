import pandas as pd
from botcity.web import WebBot


def setup_bot():
    """Configura e retorna uma instância do bot."""
    bot = WebBot()
    bot.headless = False  # Defina como True para modo headless
    return bot


def read_ceps(file_path):
    """Lê os CEPs de um arquivo Excel e retorna uma lista."""
    df = pd.read_excel(file_path)
    return df['CEP'].tolist()


def consultar_cep(bot, cep):
    """Consulta o CEP no site dos Correios e retorna os dados coletados."""
    bot.browse("https://buscacepinter.correios.com.br/app/endereco/index.php")
    bot.wait(2000)  # Aguarda o carregamento da página
    
    bot.type("input[name='cep']", cep)
    bot.click("input[type='submit']")
    bot.wait(2000)  # Aguarda a resposta

    try:
        logradouro = bot.get_text("selector_do_logradouro")
        bairro = bot.get_text("selector_do_bairro")
        cidade = bot.get_text("selector_do_cidade")
        estado = bot.get_text("selector_do_estado")

        return {
            'CEP': cep,
            'Logradouro': logradouro,
            'Bairro': bairro,
            'Cidade': cidade,
            'Estado': estado
        }
    except Exception as e:
        print(f"Erro ao consultar o CEP {cep}: {e}")
        return None


def save_results(results, output_file):
    """Salva os resultados em um arquivo Excel."""
    df_resultados = pd.DataFrame(results)
    df_resultados.to_excel(output_file, index=False)


def main():
    """Função principal para executar o bot."""
    bot = setup_bot()
    ceps = read_ceps('ceps.xlsx')
    resultados = []

    for cep in ceps:
        data = consultar_cep(bot, cep)
        if data:
            resultados.append(data)

    save_results(resultados, 'relatorio_ceps.xlsx')
    bot.stop_browser()


if __name__ == '__main__':
    main()
