#!/bin/bash

zip -r "bot_covid.zip" * -x "bot_covid.zip"