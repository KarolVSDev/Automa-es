from botcity.web import WebBot, Browser, By

def acessar_situacao_eleitoral(bot):
    bot.browse("https://www.tse.jus.br/servicos-eleitorais/autoatendimento-eleitoral#/atendimento-eleitor")
    bot.wait(1000)
    bot.maximize_window()

    # Lida com os cookies
    bot.find_element('//*[@id="modal-lgpd"]/div/div/div[2]/button', By.XPATH).click()

    # Encontra a seção de consulta cadastral
    bot.find_element('//*[@id="content"]/app-root/div/app-atendimento-eleitor/div[1]/app-menu-option[10]/button', By.XPATH).click()
    bot.wait(1000)

    # Preenche o CPF
    bot.find_element('//*[@id="modal"]/div/div/div[2]/div[2]/form/div[1]/div[1]/input', By.XPATH).click()
    bot.paste('03382390221')  # Substitua pelo valor real
    bot.wait(1000)

    # Preenche a data de nascimento
    bot.find_element('//*[@id="modal"]/div/div/div[2]/div[2]/form/div[1]/div[2]/input', By.XPATH).click()
    bot.paste('20101998')  # Substitua pelo valor real
    bot.wait(1000)
    
    # Preenche o nome da mãe
    bot.find_element('//*[@id="modal"]/div/div/div[2]/div[2]/form/div[1]/div[3]/div/input', By.XPATH).click()
    bot.paste('suelem ferreira de oliveira')  # Substitua pelo valor real
    bot.wait(1000)

    # Envia o formulário
    bot.enter()
    bot.wait(5000)

    # Gera o PDF da página
    bot.print_pdf()
    bot.wait(1000)

def coletar_informacoes_eleitor(bot):
    dado_extraido_nro_titulo = bot.find_element('//*[@id="content"]/app-root/div/app-consultar-numero-titulo-eleitor/div[1]/div[1]/p[1]/b', By.XPATH).text
    dado_extraido_situacao = bot.find_element('//*[@id="content"]/app-root/div/app-consultar-numero-titulo-eleitor/div[1]/div[1]/p[2]/span', By.XPATH).text
    dado_extraido_secao = bot.find_element('//*[@id="content"]/app-root/div/app-consultar-numero-titulo-eleitor/div[1]/app-box-local-votacao/div/div/div[2]/div[1]/span[2]', By.XPATH).text
    dado_extraido_zona = bot.find_element('//*[@id="content"]/app-root/div/app-consultar-numero-titulo-eleitor/div[1]/app-box-local-votacao/div/div/div[2]/div[3]/span[2]', By.XPATH).text
    dado_extraido_local_votacao = bot.find_element('//*[@id="content"]/app-root/div/app-consultar-numero-titulo-eleitor/div[1]/app-box-local-votacao/div/div/div[1]/div[1]/span[2]', By.XPATH).text
    dado_extraido_endereco_votacao = bot.find_element('//*[@id="content"]/app-root/div/app-consultar-numero-titulo-eleitor/div[1]/app-box-local-votacao/div/div/div[1]/div[2]/span[2]', By.XPATH).text
    dado_extraido_bairro = bot.find_element('//*[@id="content"]/app-root/div/app-consultar-numero-titulo-eleitor/div[1]/app-box-local-votacao/div/div/div[1]/div[4]/span[2]', By.XPATH).text
    dado_extraido_municipio_uf = bot.find_element('//*[@id="content"]/app-root/div/app-consultar-numero-titulo-eleitor/div[1]/app-box-local-votacao/div/div/div[1]/div[3]/span[2]', By.XPATH).text
    dado_extraido_pais = bot.find_element('//*[@id="content"]/app-root/div/app-consultar-numero-titulo-eleitor/div[1]/app-box-local-votacao/div/div/div[2]/div[2]/span[2]', By.XPATH).text

    # Retorna as informações coletadas em um dicionário
    return {
        "nro_titulo": dado_extraido_nro_titulo,
        "situacao": dado_extraido_situacao,
        "secao": dado_extraido_secao,
        "zona": dado_extraido_zona,
        "local_votacao": dado_extraido_local_votacao,
        "endereco_votacao": dado_extraido_endereco_votacao,
        "bairro": dado_extraido_bairro,
        "municipio_uf": dado_extraido_municipio_uf,
        "pais": dado_extraido_pais
    }
